#!/usr/bin/env python3
"""
daily-market plugin — 카카오톡 메시지 분할 헬퍼

950자 기준으로 메시지를 자연스러운 단락에서 분할한다.
구분선("━━"), 빈 줄, 섹션 헤더(📊/🇰🇷/🇺🇸/📌/📁 시작 줄)를 우선 분할 지점으로 선호한다.

사용법:
    echo "긴 메시지..." | python3 kakao_split.py
    python3 kakao_split.py --max 950 --input message.txt
"""

import argparse
import sys
from typing import List

DEFAULT_LIMIT = 950

# 분할 우선순위가 높은 라인 시작 패턴
SECTION_PREFIXES = ("📊", "🇰🇷", "🇺🇸", "📌", "📁", "━━")


def split_message(text: str, limit: int = DEFAULT_LIMIT) -> List[str]:
    """텍스트를 limit자 이하의 청크 리스트로 분할."""
    if len(text) <= limit:
        return [text]

    chunks: List[str] = []
    remaining = text

    while len(remaining) > limit:
        # limit 위치에서 가장 가까운 자연스러운 분할점 찾기 (limit 이하 영역에서)
        cut = _find_best_split(remaining, limit)
        chunks.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()

    if remaining:
        chunks.append(remaining)

    return chunks


def _find_best_split(text: str, limit: int) -> int:
    """text[:limit] 내에서 가장 적합한 분할 위치(end-exclusive 인덱스) 반환."""
    window = text[:limit]

    # 1순위: 섹션 시작 줄(이모지/구분선) 직전의 빈 줄
    lines = window.split("\n")
    cumulative = 0
    section_breaks = []
    for i, line in enumerate(lines):
        cumulative_after = cumulative + len(line) + 1  # +1 for newline
        if i > 0 and any(line.strip().startswith(p) for p in SECTION_PREFIXES):
            section_breaks.append(cumulative)
        cumulative = cumulative_after
    if section_breaks:
        return section_breaks[-1]  # 가장 뒤쪽(=limit에 가장 가까운) 섹션 경계

    # 2순위: 빈 줄(\n\n)
    pos = window.rfind("\n\n")
    if pos > limit * 0.5:
        return pos + 2

    # 3순위: 일반 줄바꿈
    pos = window.rfind("\n")
    if pos > limit * 0.5:
        return pos + 1

    # 4순위: 마침표·물음표·느낌표 + 공백
    for end_chars in (". ", "? ", "! ", "다. ", "다.\n"):
        pos = window.rfind(end_chars)
        if pos > limit * 0.5:
            return pos + len(end_chars)

    # 5순위: 그냥 limit에서 잘라 (최후 수단)
    return limit


def main():
    ap = argparse.ArgumentParser(description="카카오톡 메모챗용 메시지 분할기 (기본 950자)")
    ap.add_argument("--max", type=int, default=DEFAULT_LIMIT, help="최대 글자 수 (기본 950)")
    ap.add_argument("--input", help="입력 파일 (없으면 stdin)")
    ap.add_argument("--separator", default="\n---CHUNK---\n", help="청크 구분자 (출력용)")
    args = ap.parse_args()

    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            text = f.read()
    else:
        text = sys.stdin.read()

    chunks = split_message(text, args.max)

    for i, c in enumerate(chunks):
        if i > 0:
            print(args.separator, end="")
        print(c)
        print(f"\n[chunk {i+1}/{len(chunks)} — {len(c)} chars]", file=sys.stderr)


if __name__ == "__main__":
    main()
