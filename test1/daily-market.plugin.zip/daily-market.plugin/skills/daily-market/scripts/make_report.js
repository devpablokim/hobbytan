#!/usr/bin/env node
/**
 * daily-market plugin — docx 보고서 생성기
 *
 * 사용법:
 *   node make_report.js --input verified.json --output /path/to/output.docx
 *   cat verified.json | node make_report.js --output /path/to/output.docx
 *
 * verified.json 스키마는 fact-checker 서브에이전트의 출력을 따른다.
 */

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat,
  ExternalHyperlink, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber
} = require('docx');

const FONT = "Malgun Gothic";

// ---------- args ----------
function parseArgs() {
  const args = process.argv.slice(2);
  const out = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input') out.input = args[++i];
    else if (args[i] === '--output') out.output = args[++i];
    else if (args[i] === '--help' || args[i] === '-h') {
      console.log("Usage: make_report.js --input verified.json --output report.docx");
      process.exit(0);
    }
  }
  return out;
}

function readData(input) {
  let raw;
  if (input) raw = fs.readFileSync(input, 'utf8');
  else raw = fs.readFileSync(0, 'utf8'); // stdin
  return JSON.parse(raw);
}

// ---------- helpers ----------
const para = (text, opts = {}) => new Paragraph({
  spacing: { before: 80, after: 80 },
  ...opts,
  children: [new TextRun({ text, font: FONT, ...(opts.runOpts || {}) })]
});

const bullet = (text, runOpts = {}) => new Paragraph({
  numbering: { reference: "bullets", level: 0 },
  spacing: { before: 40, after: 40 },
  children: [new TextRun({ text, font: FONT, ...runOpts })]
});

const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 320, after: 160 },
  children: [new TextRun({ text, bold: true, size: 32, font: FONT, color: "1F3864" })]
});

const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  spacing: { before: 240, after: 120 },
  children: [new TextRun({ text, bold: true, size: 26, font: FONT, color: "2E75B6" })]
});

const h3 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_3,
  spacing: { before: 160, after: 80 },
  children: [new TextRun({ text, bold: true, size: 22, font: FONT, color: "404040" })]
});

const border = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: border, bottom: border, left: border, right: border };

const cell = (text, opts = {}) => new TableCell({
  borders,
  width: { size: opts.width || 2340, type: WidthType.DXA },
  margins: { top: 80, bottom: 80, left: 120, right: 120 },
  shading: opts.fill ? { fill: opts.fill, type: ShadingType.CLEAR } : undefined,
  children: [new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    children: [new TextRun({
      text: String(text),
      font: FONT,
      bold: opts.bold || false,
      color: opts.color || "000000",
      size: opts.size || 22
    })]
  })]
});

const sourceLink = (label, url) => new Paragraph({
  numbering: { reference: "bullets", level: 0 },
  spacing: { before: 40, after: 40 },
  children: [
    new TextRun({ text: label + " — ", font: FONT }),
    new ExternalHyperlink({
      children: [new TextRun({ text: url, style: "Hyperlink", font: FONT, color: "0563C1", underline: { type: "single" } })],
      link: url
    })
  ]
});

function fmtChange(n) {
  if (n === undefined || n === null) return "-";
  return (n >= 0 ? "+" : "") + Number(n).toFixed(2);
}
function fmtPct(n) {
  if (n === undefined || n === null) return "-";
  return (n >= 0 ? "+" : "") + Number(n).toFixed(2) + "%";
}
function colorByPct(n) {
  if (n === undefined || n === null) return "000000";
  return n < 0 ? "0070C0" : "C00000";
}
function fmtNum(n) {
  if (n === undefined || n === null) return "-";
  return Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ---------- build ----------
function buildDocument(data) {
  const date = data.target_date || "";
  const kr = (data.verified_facts && data.verified_facts.kr_market) || {};
  const us = (data.verified_facts && data.verified_facts.us_market) || {};
  const sources = data.all_sources || [];
  const discrepancies = data.discrepancies || [];

  // ---- Title block ----
  const titlePara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 120 },
    children: [new TextRun({
      text: `${date} 한국·미국 증시 마감 보고서`,
      bold: true, size: 40, font: FONT, color: "1F3864"
    })]
  });
  const subtitlePara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 80 },
    children: [new TextRun({
      text: `자동 생성 · 출처 ${sources.length}건 교차 검증`,
      italics: true, size: 22, font: FONT, color: "595959"
    })]
  });
  const datePara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 360 },
    children: [new TextRun({
      text: `작성: ${data.verified_at || new Date().toISOString().slice(0,10)}`,
      size: 20, font: FONT, color: "808080"
    })]
  });

  // ---- Summary table ----
  const summaryHeader = new TableRow({
    tableHeader: true,
    children: [
      cell("구분", { fill: "1F3864", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 1800 }),
      cell("지수", { fill: "1F3864", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 2200 }),
      cell("종가",  { fill: "1F3864", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 1900 }),
      cell("등락폭", { fill: "1F3864", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 1700 }),
      cell("등락률", { fill: "1F3864", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 1760 }),
    ]
  });

  function summaryRow(area, name, idx, fill) {
    if (!idx) return null;
    return new TableRow({ children: [
      cell(area, { fill, align: AlignmentType.CENTER, bold: true, width: 1800 }),
      cell(name, { fill, width: 2200 }),
      cell(fmtNum(idx.close), { fill, align: AlignmentType.RIGHT, bold: true, width: 1900 }),
      cell(fmtChange(idx.change), { fill, align: AlignmentType.RIGHT, color: colorByPct(idx.change_pct), width: 1700 }),
      cell(fmtPct(idx.change_pct), { fill, align: AlignmentType.RIGHT, color: colorByPct(idx.change_pct), width: 1760 }),
    ]});
  }

  const summaryRows = [
    summaryRow("한국", "코스피", kr.kospi, "FCE4D6"),
    summaryRow("한국", "코스닥", kr.kosdaq, "FCE4D6"),
    summaryRow("한국", "원·달러", kr.fx_usd_krw && {close: kr.fx_usd_krw.close, change: kr.fx_usd_krw.change, change_pct: kr.fx_usd_krw.change_pct}, "FCE4D6"),
    summaryRow("미국", "다우",    us.dow,    "DDEBF7"),
    summaryRow("미국", "S&P 500", us.sp500,  "DDEBF7"),
    summaryRow("미국", "나스닥",  us.nasdaq, "DDEBF7"),
  ].filter(Boolean);

  const summaryTable = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1800, 2200, 1900, 1700, 1760],
    rows: [summaryHeader, ...summaryRows]
  });

  // ---- KR movers table ----
  const krMovers = (kr.key_movers || []);
  const krMoversTable = krMovers.length ? new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 2120, 4120],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          cell("종목", { fill: "C00000", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 3120 }),
          cell("등락률", { fill: "C00000", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 2120 }),
          cell("코멘트", { fill: "C00000", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 4120 }),
        ]
      }),
      ...krMovers.map(m => new TableRow({ children: [
        cell(m.name, { width: 3120, bold: true }),
        cell(fmtPct(m.pct), { width: 2120, align: AlignmentType.CENTER, color: colorByPct(m.pct), bold: true }),
        cell(m.note || "", { width: 4120 }),
      ]}))
    ]
  }) : null;

  // ---- US movers table ----
  const usMovers = (us.key_movers || []);
  const usMoversTable = usMovers.length ? new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3120, 2120, 4120],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          cell("종목", { fill: "2E75B6", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 3120 }),
          cell("등락률", { fill: "2E75B6", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 2120 }),
          cell("코멘트", { fill: "2E75B6", color: "FFFFFF", bold: true, align: AlignmentType.CENTER, width: 4120 }),
        ]
      }),
      ...usMovers.map(m => new TableRow({ children: [
        cell(m.name, { width: 3120, bold: true }),
        cell(fmtPct(m.pct), { width: 2120, align: AlignmentType.CENTER, color: colorByPct(m.pct), bold: true }),
        cell(m.note || "", { width: 4120 }),
      ]}))
    ]
  }) : null;

  const children = [titlePara, subtitlePara, datePara];

  // 1. Summary
  children.push(h1("1. 한눈에 보는 요약"));
  if (data.summary_text) children.push(para(data.summary_text));
  children.push(summaryTable);

  // 2. Korean market
  children.push(h1("2. 한국 증시"));
  if (kr.kospi) {
    children.push(bullet(`코스피: ${fmtNum(kr.kospi.close)} (${fmtChange(kr.kospi.change)}, ${fmtPct(kr.kospi.change_pct)})`));
  }
  if (kr.kosdaq) {
    children.push(bullet(`코스닥: ${fmtNum(kr.kosdaq.close)} (${fmtChange(kr.kosdaq.change)}, ${fmtPct(kr.kosdaq.change_pct)})`));
  }
  if (kr.fx_usd_krw) {
    children.push(bullet(`원·달러 환율: ${fmtNum(kr.fx_usd_krw.close)} (${fmtChange(kr.fx_usd_krw.change)})`));
  }
  if (kr.flow) {
    children.push(h3("수급 (단위: 억원)"));
    children.push(bullet(`외국인 ${kr.flow.foreign_eok}, 기관 ${kr.flow.institution_eok}, 개인 ${kr.flow.retail_eok}`));
  }
  if (kr.macro) {
    children.push(h3("거시 변수"));
    children.push(para(kr.macro));
  }
  if (krMoversTable) {
    children.push(h3("주요 종목 등락"));
    children.push(krMoversTable);
  }

  // 3. US market
  children.push(h1("3. 미국 증시 (현지시간)"));
  if (us.dow)    children.push(bullet(`다우존스: ${fmtNum(us.dow.close)} (${fmtPct(us.dow.change_pct)})`));
  if (us.sp500)  children.push(bullet(`S&P 500: ${fmtNum(us.sp500.close)} (${fmtPct(us.sp500.change_pct)})`));
  if (us.nasdaq) children.push(bullet(`나스닥: ${fmtNum(us.nasdaq.close)} (${fmtPct(us.nasdaq.change_pct)})`));
  if (us.monthly_summary) {
    children.push(h3("월간 성과"));
    children.push(para(us.monthly_summary));
  }
  if (us.macro) {
    children.push(h3("거시 변수"));
    children.push(para(us.macro));
  }
  if (usMoversTable) {
    children.push(h3("주요 종목 등락"));
    children.push(usMoversTable);
  }

  // 4. Implications
  if (data.implications) {
    children.push(h1("4. 종합 시사점"));
    children.push(para(data.implications));
  }

  // 5. Discrepancies
  if (discrepancies.length) {
    children.push(h1("5. 신뢰도 메모"));
    discrepancies.forEach(d => {
      children.push(bullet(`[${d.metric}] ${d.resolution || '값 불일치'} — confidence=${d.confidence || 'low'}`));
    });
  }

  // 6. Sources
  if (sources.length) {
    children.push(h1((discrepancies.length ? "6" : "5") + ". 출처"));
    sources.forEach(s => {
      const label = `[${s.media || 'source'}] ${s.title || s.url}`;
      children.push(sourceLink(label, s.url));
    });
  }

  return new Document({
    creator: "daily-market plugin",
    title: `${date} 한국·미국 증시 마감 보고서`,
    styles: { default: { document: { run: { font: FONT, size: 22 } } } },
    numbering: {
      config: [{
        reference: "bullets",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 270 } } }
        }]
      }]
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
        }
      },
      headers: {
        default: new Header({ children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: `한국·미국 증시 마감 — ${date}`, font: FONT, size: 18, color: "808080" })]
        })] })
      },
      footers: {
        default: new Footer({ children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", font: FONT, size: 18, color: "808080" }),
            new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18, color: "808080" }),
          ]
        })] })
      },
      children
    }]
  });
}

// ---------- run ----------
const args = parseArgs();
if (!args.output) {
  console.error("--output is required");
  process.exit(1);
}
const data = readData(args.input);
const doc = buildDocument(data);
Packer.toBuffer(doc).then(buf => {
  fs.mkdirSync(path.dirname(args.output), { recursive: true });
  fs.writeFileSync(args.output, buf);
  console.log(`Wrote ${args.output} (${buf.length} bytes)`);
});
