---
name: daily-market
description: 매일 한국·미국 증시 마감 정보를 다양한 한국 증권 미디어에서 병렬 수집하고 네이버 검색으로 교차 검증한 뒤, 팩트체크 후 docx 보고서를 사용자 폴더에 저장하고, 핵심 요약을 카카오톡으로 발송하는 종합 자동화 스킬. 사용자가 "오늘/어제 증시 정리해줘", "일일 마켓 리포트", "장 마감 보고서" 등을 요청할 때 사용한다.
---

# Daily Market — 일일 한국·미국 증시 마감 자동 보고

이 스킬은 다음 4단계를 자동화한다.
1. 다중 출처 병렬 수집 (Chrome MCP + 네이버 MCP)
2. 팩트체크 (서브에이전트로 교차 검증)
3. docx 보고서 생성 및 사용자 폴더 저장
4. 핵심 요약을 카카오톡 메모챗으로 발송 (1메시지 ≤ 950자)

## 사용 시점 (트리거)
- "오늘 증시 마감 정리해줘", "어제 미국증시 어떻게 됐어?"
- "일일 마켓 리포트", "/daily-market" 슬래시 커맨드
- "코스피·나스닥 마감 보고서 만들어줘"

## 입력 파라미터
- `target_date` (선택): 조사할 거래일. 미지정 시 오늘 한국시간 기준 가장 최근 마감 거래일.
- `output_folder` (선택): 보고서 저장 폴더. 기본값 = 사용자 작업 폴더.
- `send_kakao` (선택, 기본 true): 카카오톡 발송 여부.

## 워크플로우

### Step 1: 거래일 확정
`mcp__...NaverSearch-get_current_korean_time`으로 현재 한국 시간을 확인하고, 사용자가 target_date를 명시하지 않았다면:
- 평일 오후 4시 이후 → 오늘 거래일
- 평일 오후 4시 이전 → 직전 거래일
- 주말/공휴일 → 직전 평일 거래일

### Step 2: 서브에이전트 병렬 호출 (가장 중요)
**한 메시지에 두 개의 Agent 도구 호출을 동시에 보낸다.** 이렇게 해야 두 서브에이전트가 진짜로 병렬 실행된다.

```
Agent({
  description: "Chrome 다중매체 수집",
  subagent_type: "chrome-stock-researcher",
  prompt: "target_date=2026-04-30 / 한국경제·매일경제·조선비즈·이데일리·머니투데이 5개 매체에서 한국 증시 마감과 미국 증시(현지시간 동일 거래일) 마감 정보를 수집해서 명세된 JSON 형식으로 반환."
})

Agent({
  description: "네이버 뉴스 교차 확인",
  subagent_type: "naver-stock-researcher",
  prompt: "target_date=2026-04-30 / NaverSearch-search_news로 코스피·코스닥·뉴욕증시 마감 관련 다매체 기사를 모아 명세된 JSON 형식으로 반환."
})
```

**규칙**: 두 Agent 호출은 반드시 같은 메시지의 별도 tool_use 블록 두 개로 보낸다. 순차 호출하면 안 된다.

### Step 3: 팩트체크
두 결과가 모두 도착하면 fact-checker 서브에이전트를 한 번 더 호출한다:

```
Agent({
  description: "두 출처군 교차 검증",
  subagent_type: "fact-checker",
  prompt: "chrome_results={...}, naver_results={...}, target_date=2026-04-30 / 두 출처를 교차 비교하여 confidence 등급을 부여한 verified_facts JSON을 반환."
})
```

### Step 4: docx 보고서 생성
`scripts/make_report.js` 스크립트에 verified_facts JSON을 표준입력으로 전달하여 docx를 생성한다.

```bash
node scripts/make_report.js \
  --input  /tmp/verified.json \
  --output "/Users/{user}/Documents/{folder}/{YYYY-MM-DD}_한국미국증시_마감보고서.docx"
```

스크립트는 다음을 포함하는 docx를 만든다:
- 표지 (제목·작성일·출처 매체 수)
- 한눈에 보는 요약 표 (한·미 지수)
- 한국 증시 섹션 (지수·수급·종목·거시)
- 미국 증시 섹션 (지수·월간·빅테크·거시)
- 종합 시사점
- 출처 링크 (모든 매체 URL)
- discrepancies가 있으면 "신뢰도 메모" 섹션 추가

### Step 5: 카카오톡 발송
`mcp__...KakaotalkChat-MemoChat`으로 핵심 요약을 발송한다.

**메시지 작성 규칙:**
- 1메시지 ≤ 950자 (UTF-8 모든 문자 포함)
- 950자 초과 시 자연스러운 단락에서 분할 (지수 요약 / 핵심 포인트 / 출처)
- 형식 템플릿:

```
📊 [{YYYY.M.D} 한국·미국 증시 마감]
━━━━━━━━━━━
🇰🇷 한국 ({요약 한 줄})
· 코스피 {종가} ({등락률})
· 코스닥 {종가} ({등락률})
· 원·달러 {환율}
{2-3문장 요약}

🇺🇸 미국 ({요약 한 줄})
· 다우 {종가} ({등락률})
· S&P500 {종가} ({등락률})
· 나스닥 {종가} ({등락률})
{2-3문장 요약 + 빅테크 명암}

📌 꼭 알아둘 점
① {포인트1}
② {포인트2}
③ {포인트3}

📁 상세 보고서: {파일명} (작업 폴더에 저장됨)
```

**950자 카운팅 규칙:**
- 줄바꿈, 공백, 이모지 모두 1자 이상으로 카운트
- 발송 전 `len(message)`로 길이 검증, 초과 시 자동 분할

## 에러 처리
- Chrome MCP가 연결 안 됨 → 사용자에게 안내하고 네이버 MCP만으로 진행 (저신뢰 보고서)
- 네이버 MCP가 실패 → Chrome MCP만으로 진행
- 두 MCP 모두 실패 → 작업 중단, 사용자에게 보고
- 카카오 MCP가 실패 → docx까지는 완료하고 발송만 건너뜀
- target_date에 거래가 없었음(휴장) → 직전 거래일로 자동 보정 + 사용자에게 알림

## 출력
사용자에게는 짧게 보고:
1. 어떤 거래일을 조사했는지
2. 몇 개 매체에서 데이터를 모았는지
3. docx 파일 링크 (computer:// 형식)
4. 카카오톡 발송 여부
5. 불일치/주의 사항이 있다면 한 줄 요약

## 관련 파일
- `scripts/make_report.js` — docx 생성 스크립트 (Node.js, 의존성 `docx`)
- `scripts/kakao_split.py` — 950자 기준 카톡 메시지 분할 헬퍼
- 슬래시 커맨드: `/daily-market`
- 서브에이전트: chrome-stock-researcher, naver-stock-researcher, fact-checker
