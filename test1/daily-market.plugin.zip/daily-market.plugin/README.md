# daily-market.plugin

매일 한국·미국 증시 마감 정보를 자동으로 수집·검증·보고하는 Claude 플러그인입니다.

## 무엇을 해주나요

`/daily-market` 한 번만 실행하면:

1. **다중 매체 동시 조사** — Claude for Chrome으로 한국경제·매일경제·조선비즈·이데일리·머니투데이 5개 한국 증권 매체를 순회하면서 같은 거래일의 마감 시황을 수집합니다.
2. **네이버 뉴스 교차 확인** — 동시에 네이버 검색 MCP로 같은 거래일의 다매체 뉴스를 모아 두 번째 출처군을 확보합니다. (위 1번과 병렬 실행)
3. **팩트체크** — 두 출처군의 핵심 수치(지수 종가·등락률·수급·종목 등락·거시 변수)를 교차 비교하여 일치하면 high confidence, 불일치는 다수결·메모로 처리합니다.
4. **docx 보고서 생성** — 검증된 데이터로 깔끔한 docx를 만들어 사용자 폴더에 저장합니다.
5. **카카오톡 요약 발송** — 핵심 요약을 본인 카톡(메모챗)으로 보냅니다. 1메시지 950자 이내, 초과 시 자연스러운 단락에서 자동 분할됩니다.

## 폴더 구조

```
daily-market.plugin/
├── .claude-plugin/
│   └── plugin.json                     # 매니페스트
├── skills/
│   └── daily-market/
│       ├── SKILL.md                    # 메인 스킬 (오케스트레이션)
│       └── scripts/
│           ├── make_report.js          # docx 생성기 (Node.js)
│           └── kakao_split.py          # 950자 분할 헬퍼 (Python)
├── agents/
│   ├── chrome-stock-researcher.md      # Chrome 다중 매체 수집 서브에이전트
│   ├── naver-stock-researcher.md       # 네이버 뉴스 검색 서브에이전트
│   └── fact-checker.md                 # 교차 검증 서브에이전트
├── commands/
│   └── daily-market.md                 # /daily-market 슬래시 커맨드
└── README.md                           # 이 파일
```

## 필요한 MCP

이 플러그인은 다음 MCP가 연결되어 있어야 정상 동작합니다.

| MCP | 용도 | 도구 |
|---|---|---|
| Claude in Chrome | 한국 증권 매체 동시 브라우징 | `mcp__Claude_in_Chrome__*` |
| Naver Search (PlayMCP) | 네이버 뉴스 검색·시간 조회 | `NaverSearch-search_news`, `NaverSearch-get_current_korean_time` |
| KakaoTalk MemoChat (PlayMCP) | 본인에게 카톡 발송 | `KakaotalkChat-MemoChat` |

## 의존성

- **Node.js** + `docx` 패키지: docx 생성용
  ```bash
  npm install docx
  ```
- **Python 3**: 카톡 메시지 분할 헬퍼

## 사용법

```
/daily-market                # 가장 최근 마감 거래일 자동 보고
/daily-market 2026-04-30     # 특정 거래일 보고
/daily-market yesterday      # 어제 거래일 보고
```

또는 자연어로:
- "오늘 증시 마감 정리해줘"
- "어제 미국증시 어땠어? 보고서로 만들어줘"
- "코스피·나스닥 일일 마켓 리포트"

## 설계 메모

- **병렬 실행이 핵심**: chrome-stock-researcher와 naver-stock-researcher는 반드시 같은 메시지의 두 개 Agent 호출로 동시 실행되도록 SKILL.md에 명시했습니다. 순차로 실행하면 시간이 두 배가 됩니다.
- **저작권 안전**: 각 매체 인용은 30자 이내로 제한, 본문 통째 복사 금지.
- **카톡 950자 규칙**: 도구 설명상 200자 한도이지만 실측상 약 1,000자에서 잘립니다. 안전 마진으로 950자를 기준으로 분할합니다.
- **discrepancies 보존**: 두 출처군이 충돌하면 보고서 끝에 "신뢰도 메모" 섹션을 자동 추가해 사용자가 직접 판단할 수 있게 합니다.
