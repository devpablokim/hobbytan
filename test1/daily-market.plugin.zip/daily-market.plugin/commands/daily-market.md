---
description: 한국·미국 증시 마감 보고서를 다중 매체에서 자동 수집·검증 후 docx로 저장하고 카톡으로 요약 발송
argument-hint: "[YYYY-MM-DD] (생략 시 가장 최근 마감 거래일)"
---

# /daily-market

`daily-market` 스킬을 호출해 다음을 수행합니다.

1. **다중 출처 병렬 수집**
   - `chrome-stock-researcher` 서브에이전트로 한국경제·매일경제·조선비즈·이데일리·머니투데이 5개 매체 브라우징
   - 동시에 `naver-stock-researcher` 서브에이전트로 네이버 뉴스 검색

2. **팩트체크**
   - `fact-checker` 서브에이전트가 두 출처군 결과를 교차 검증

3. **docx 보고서 생성**
   - `make_report.js`로 docx를 생성해 사용자 폴더(`/Users/pablokim/Documents/kakao-test1`)에 저장

4. **카카오톡 요약 발송**
   - 핵심 요약을 본인에게 카톡으로 발송 (1메시지 ≤ 950자, 초과 시 자동 분할)

## 사용 예

```
/daily-market
/daily-market 2026-04-30
/daily-market yesterday
```

## 인자 처리
- 인자 없음 → 현재 한국시간 기준 가장 최근 마감 거래일
- `YYYY-MM-DD` → 해당 거래일 (휴장이면 직전 거래일로 자동 보정)
- `yesterday`, `today` → 자연어 처리

스킬 실행 후 결과 요약(파일 링크 + 카톡 발송 여부)을 짧게 보고합니다.
